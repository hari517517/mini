USE Training_23Jan19_Pune
Go

CREATE TABLE Users_172476
(
UserId           INT, 
UserName         VARCHAR(50), 
Password         VARCHAR(50), 
FirstName        VARCHAR(50), 
LastName         VARCHAR(50)
)
GO

CREATE TABLE Roles_172476
(
 RoleId   INT, 
 RoleName VARCHAR(50)
) 
GO

CREATE TABLE UserRoles_172476
(
 UserId        INT, 
 RoleId        INT
)
GO
CREATE TABLE Team_172476
(
Id                INT, 
Name              VARCHAR(55), 
HomeGround        VARCHAR(60), 
Franchise         VARCHAR(60), 
LogoImage         VARBINARY(MAX)       
)

GO
CREATE TABLE Player_172476
(
Id                   INT, 
TeamId               BIGINT, 
Name                 VARCHAR(50),
Age                  INT,
Speciality           VARCHAR(50)
)
GO
CREATE TABLE PlayerPhoto_172476
(
PlayerId               INT, 
Photo                  VARBINARY(MAX)
)
GO

CREATE TABLE Speciality_172476
(
SpecialityId                    INT, 
SpecialityDescription           VARCHAR(60)
)
GO
CREATE TABLE Match_172476
(
Id                          INT, 
TeamOneId                   BIGINT, 
TeamTwoId                   BIGINT, 
VenueId                     BIGINT, 
ScheduleId                  BIGINT, 
PhotoGroupId                BIGINT
)
GO
CREATE TABLE MatchPhoto_172476
(
Id                  INT, 
MatchId             BIGINT, 
Photo               VARBINARY(MAX)
)
GO
CREATE TABLE Venue_172476
(
Id                     BIGINT, 
Location               VARCHAR(55), 
Description            VARCHAR(60)
)
GO
CREATE TABLE Schedule_172476
(
Id                        INT, 
MatchId                   BIGINT, 
VenueId                   BIGINT, 
Date                      DATETIME, 
StartTime                 DATETIME, 
EndTime                   DATETIME
)
GO
CREATE TABLE Ticket_172476
(
Id                       INT, 
MatchId                  BIGINT, 
CategoryId               INT, 
Price                    INT
)
GO
CREATE TABLE TicketCategory_172476
(
Id                       INT, 
Name                     VARCHAR(50), 
Description              VARCHAR(60)
)
GO
CREATE TABLE News_172476
(
Id                      INT, 
NewsDate                DATETIME, 
MatchId                 BIGINT, 
Description             VARCHAR(60), 
MatchPhotoId            VARBINARY(MAX)
)
GO
CREATE TABLE Statitics_172476
(
TeamId                BIGINT, 
Played                INT, 
Won                   INT, 
Lost                  INT, 
Tied                  INT, 
NR                    INT, 
NetRR                 DECIMAL, 
ForAgainst            VARCHAR(50), 
Pts                   INT
)